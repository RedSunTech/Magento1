<?php

class SunTech_PayCode_Model_Payment extends Mage_Payment_Model_Method_Abstract
{
    protected $_code = "suntech_paycode";
    protected $_formBlockType = 'suntech_paycode/form_pay';
    protected $_infoBlockType = 'suntech_paycode/info_pay';
    protected $_isGateway = false;
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    protected $_canVoid = false;
    protected $_canUseInternal = false;
    protected $_canUseCheckout = true;
    protected $_canUseForMultishipping = false;
    protected $_paymentMethod = 'suntech_paycode';
    protected $_order;

    public function isAvailable($quote = null)
    {
        if (!parent::isAvailable($quote)) {
            return false;
        }

        if (!$quote) {
            return false;
        }

        if ($quote->getAllVisibleItems() <= 2) {
            return false;
        }

        return true;
    }

    public function validate()
    {
        parent::validate();

        // This returns Mage_Sales_Model_Quote_Payment, or the Mage_Sales_Model_Order_Payment
        $info = $this->getInfoInstance();
        $due_date = $info->getDueDate();
        $select_cargo_flag = $info->getSelectCargoFlag();
        $check_date = Date('Y-m-d', strtotime("+" . $this->getConfigData('due_date') . " days"));

        if ($due_date != $check_date) {
           Mage::throwException($this->_getHelper()->__('Due Date Error'));
        }
        
        if($this->getConfigData('cargo_flag')) {
            $_yesno = Mage::getModel('adminhtml/system_config_source_yesno')->toArray();
            if(!isset($_yesno[$select_cargo_flag])) {
                Mage::throwException($this->_getHelper()->__('Cargo Flag Error'));
            }
        }

        return $this;
    }

    public function getOrderPlaceRedirectUrl()
    {
        return Mage::getUrl('suntech_paycode/payment/redirect', array('_secure' => false));
    }

}