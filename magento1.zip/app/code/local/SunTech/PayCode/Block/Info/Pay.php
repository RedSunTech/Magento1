<?php

class SunTech_PayCode_Block_Info_Pay extends Mage_Payment_Block_Info
{
    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation) {
            return $this->_paymentSpecificInformation;
        }
        $info = $this->getInfo();
        $transport = new Varien_Object();
        $_yesno = Mage::getModel('adminhtml/system_config_source_yesno')->toArray();
        
        $data = array();
        $data[Mage::helper('suntech_paycode')->__('Due Date Frontend')] = $info->getDueDate();
        if($this->getConfig('cargo_flag')) {
            $data[Mage::helper('suntech_paycode')->__('Cargo Flag')] = $_yesno[$info->getSelectCargoFlag()];
        }
        $transport->addData($data);
        $transport = parent::_prepareSpecificInformation($transport);
        return $transport;
    }

    private function getConfig($keyword)
    {
        return Mage::getStoreConfig('payment/suntech_paycode/' . $keyword);
    }
}