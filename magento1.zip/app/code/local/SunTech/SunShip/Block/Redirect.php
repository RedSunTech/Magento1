<?php

class SunTech_SunShip_Block_Redirect extends Mage_Payment_Block_Info
{

    /**
     * Return checkout session instance
     *
     * @return Mage_Checkout_Model_Session
     */
    protected function _getCheckout()
    {
        return Mage::getSingleton('checkout/session');
    }

    /**
     * Return order instance
     *
     * @return Mage_Sales_Model_Order|null
     */
    protected function _getOrder()
    {
        if ($this->getOrder()) {
            return $this->getOrder();
        } elseif ($orderIncrementId = $this->_getCheckout()->getLastRealOrderId()) {
            return Mage::getModel('sales/order')->loadByIncrementId($orderIncrementId);
        } else {
            return null;
        }
    }

    private function _getConfigData($keyword)
    {
        return Mage::getStoreConfig('payment/suntech_sunship/' . $keyword, null);
    }

    private function _getInfo()
    {
        $info = $this->getData('installments');
        if (!($info instanceof Mage_Payment_Model_Info)) {
            // Mage::throwException($this->__('Cannot retrieve the payment info model object.'));
        }
        return $info;
    }

    protected function AutoSubmit()
    {
        $order_info = $this->_getOrder();
        $_cargo_flag = $order_info->getPayment()->getSelectCargoFlag();
        $shtml = '';
        if ($order_info) {
            try {
                $phone = $order_info->getBillingAddress()->getTelephone();
                $target = "_self";

                //判斷是否測試模式
                $url = ($this->_getConfigData('test_mode') == '0' ? 'https://www.esafe.com.tw/Service/Etopm.aspx' : 'https://test.esafe.com.tw/Service/Etopm.aspx');
                $DueDate = Date('Ymd', strtotime("+" . $this->_getConfigData('due_date') . " days"));
                Mage::getSingleton('checkout/session')->setSunShipDueDate($DueDate);
                $ProductName = $this->_getConfigData('product_name');
                $total_pay = intval(round($order_info["grand_total"]));

                //送出付款資訊
                $shtml = '<div style="text-align:center;" ><form name="myform" id="myform" method="post" target="' . $target . '" action="' . $url . '">';
                $shtml .= "<input type='hidden' name='web' value='" . $this->_getConfigData('web_id') . "' />"; //商店代號
                $shtml .= "<input type='hidden' name='MN' value='" . $total_pay . "' />"; //交易金額
                $shtml .= "<input type='hidden' name='Td' value='" . $order_info["increment_id"] . "' />"; //商家訂單編號
                $shtml .= "<input type='hidden' name='sna' value='" . $order_info['customer_lastname'] . $order_info['customer_middlename'] . $order_info['customer_firstname'] . "' />"; //消費者姓名
                if (preg_match("/^[0-9]+$/", $phone) == 1) {
                    $shtml .= "<input type='hidden' name='sdt' value='" . $phone . "' />"; //消費者電話
                }
                $shtml .= "<input type='hidden' name='email' value='" . $order_info["customer_email"] . "' />"; //消費者 Email
                $shtml .= "<input type='hidden' name='note1' value='sunship' />";
                $shtml .= "<input type='hidden' name='ChkValue' value='" . strtoupper(sha1($this->_getConfigData('web_id') . $this->_getConfigData('web_pwd') . $total_pay)) . "' />";
                $shtml .= '<script type="text/javascript">document.myform.submit();</script>';
                $shtml .= '</form></div>';
            } catch (Exception $e) {
                Mage::throwException($e->getMessage());
            }
        }

        return $shtml;
    }

}
