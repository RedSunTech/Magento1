<?php
$installer = $this;
$installer->startSetup();
$conn = $installer->getConnection();

// order_payment
$orderTable = $installer->getTable('sales/order_payment');
$conn->addColumn($orderTable, 'due_date', "DATE comment 'Due Date'");
$conn->addColumn($orderTable, 'select_cargo_flag', "TINYINT(1) UNSIGNED NOT NULL DEFAULT '0' comment 'Selected Cargo Flag'");

// quote_payment
$quoteTable = $installer->getTable('sales/quote_payment');
$conn->addColumn($quoteTable, 'due_date', "DATE comment 'Due Date'");
$conn->addColumn($quoteTable, 'select_cargo_flag', "TINYINT(1) UNSIGNED NOT NULL DEFAULT '0' comment 'Selected Cargo Flag'");

$installer->endSetup();