<?php

class SunTech_BuySafe_Block_Form_Pay extends Mage_Core_Block_Template
{
    protected function _construct()
    {
        parent::_construct();

        $this->setTemplate('suntech/buysafe/form/pay.phtml');
    }

     /**
     * Retrieve available credit card installments
     *
     * @return array
     */
    public function getCcAvailableInstallments()
    {
        $installments = Mage::getModel('suntech_buysafe/installments')->getAvailableArray();
        return $installments;
    }

    public function getConfig($keyword)
    {
        return Mage::getStoreConfig('payment/suntech_buysafe/' . $keyword);
    }
}