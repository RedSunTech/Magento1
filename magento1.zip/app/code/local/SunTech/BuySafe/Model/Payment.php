<?php

class SunTech_BuySafe_Model_Payment extends Mage_Payment_Model_Method_Abstract
{
    protected $_code = "suntech_buysafe";
    protected $_formBlockType = 'suntech_buysafe/form_pay';
    protected $_infoBlockType = 'suntech_buysafe/info_pay';
    protected $_isGateway = false;
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    protected $_canVoid = false;
    protected $_canUseInternal = false;
    protected $_canUseCheckout = true;
    protected $_canUseForMultishipping = false;
    protected $_paymentMethod = 'suntech_buysafe';
    protected $_order;

    public function isAvailable($quote = null)
    {
        if (!parent::isAvailable($quote)) {
            return false;
        }

        if (!$quote) {
            return false;
        }

        if ($quote->getAllVisibleItems() <= 2) {
            return false;
        }

        return true;
    }

    public function validate()
    {
        parent::validate();

        // This returns Mage_Sales_Model_Quote_Payment, or the Mage_Sales_Model_Order_Payment
        $info = $this->getInfoInstance();

        $select_installments = $info->getSelectInstallments();
        $select_cargo_flag = $info->getSelectCargoFlag();
        $available_installments = Mage::getModel('suntech_buysafe/installments')->getAvailableArray();
        if(!isset($available_installments[$select_installments])) {
            Mage::throwException($this->_getHelper()->__('Installments Error'));
        }

        if($this->getConfigData('cargo_flag')) {
            $_yesno = Mage::getModel('adminhtml/system_config_source_yesno')->toArray();
            if(!isset($_yesno[$select_cargo_flag])) {
                Mage::throwException($this->_getHelper()->__('Cargo Flag Error'));
            }
        }

        return $this;
    }

    public function getOrderPlaceRedirectUrl()
    {
        return Mage::getUrl('suntech_buysafe/payment/redirect', array('_secure' => false));
    }

}