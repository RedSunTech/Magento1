<?php
class SunTech_BuySafe_Model_Installments
{
    protected $_options;
    private $_installments;
    public function __construct()
    {
        $this->_installments = array(
            3 => Mage::helper('payment')->__('3 installments'),
            6 => Mage::helper('payment')->__('6 installments'),
            12 => Mage::helper('payment')->__('12 installments'),
            18 => Mage::helper('payment')->__('18 installments'),
            24 => Mage::helper('payment')->__('24 installments')
        );
    }

    public function toOptionArray($isMultiselect=false)
    {
        if (!$this->_options) {
            foreach ($this->_installments as $key => $installment) {
                $this->_options[] = array('value' => $key, 'label' => $installment);
            }
        }

        $options = $this->_options;
        if(!$isMultiselect){
            array_unshift($options, array('value'=>'', 'label'=> Mage::helper('adminhtml')->__('--Please Select--')));
        }

        return $options;
    }

    /**
     * Retrieve available credit card installments
     *
     * @return array
     */
    public function getAvailableArray()
    {
        $installments = $this->_installments;
        $availableInstallments = Mage::getStoreConfig('payment/suntech_buysafe/installments');
            if ($availableInstallments) {
                $availableInstallments = explode(',', $availableInstallments);
                foreach ($installments as $installment => $name) {
                    if (!in_array($installment, $availableInstallments)) {
                        unset($installments[$installment]);
                    }
                }
            }
            else return [];
        $installments[0] = Mage::helper('payment')->__('Lump Sum');
        ksort($installments);
//        array_unshift($installments, Mage::helper('payment')->__('Lump Sum'));
        return $installments;
    }


}
