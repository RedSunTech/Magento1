<?php

class SunTech_UnionPay_Block_Form_Pay extends Mage_Core_Block_Template
{
    protected function _construct()
    {
        parent::_construct();

        $this->setTemplate('suntech/unionpay/form/pay.phtml');
    }

    public function getConfig($keyword)
    {
        return Mage::getStoreConfig('payment/suntech_unionpay/' . $keyword);
    }
}