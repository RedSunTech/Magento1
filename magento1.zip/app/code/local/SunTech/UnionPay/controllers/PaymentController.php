<?php

class SunTech_UnionPay_PaymentController extends Mage_Core_Controller_Front_Action
{
    protected $_order = NULL;

    /**
     * Get singleton of Checkout Session Model
     *
     * @return Mage_Checkout_Model_Session
     */
    protected function _getSession()
    {
        return Mage::getSingleton('checkout/session');
    }

    protected function _getPendingPaymentStatus()
    {
        return Mage::helper('suntech_unionpay')->getPendingPaymentStatus();
    }

    /**
     * Add Order Backend Comment
     *
     * @param string $comment
     * @param bool $status
     */
    private function _addAdminComment($comment, $status = false)
    {
        $this->_order->addStatusHistoryComment($comment, $status);
    }

    /**
     * Add Order Frontend Comment
     *
     * @param string $comment
     * @param bool $status
     * @param bool $notify
     * @param bool $front
     * @param bool $send_email
     */
    private function _addCustomerComment($comment, $status = false, $notify = true, $front = true, $send_email = true)
    {
        $this->_order->addStatusHistoryComment($comment, $status)
            ->setIsCustomerNotified($notify)
            ->setIsVisibleOnFront($front);
        $this->_order->save();

        if ($send_email) {
            $this->_order->sendOrderUpdateEmail(true, $comment);    
        }
    }

    private function _getConfigData($keyword)
    {
        return Mage::getStoreConfig('payment/suntech_unionpay/' . $keyword, null);
    }

    private function _getOrder($orderID = NULL)
    {
        if (!isset($orderID)) {
            $orderID = $this->_getSession()->getLastRealOrderId();
        }
        if ($orderID) {
            return Mage::getModel('sales/order')->loadByIncrementId($orderID);
        } else {
            return null;
        }
    }

    /**
     * when customer selects payment method
     */
    public function redirectAction()
    {
        try {
            $session = $this->_getSession();
            $order = Mage::getModel('sales/order');
            $order->loadByIncrementId($session->getLastRealOrderId());
            if (!$order->getId()) {
                Mage::throwException(Mage::helper('payment')->__('Order Not Found'));
            }
            if ($order->getState() != Mage_Sales_Model_Order::STATE_PENDING_PAYMENT) {
                $order->setState(Mage_Sales_Model_Order::STATE_PENDING_PAYMENT, $this->_getPendingPaymentStatus())->save();
                $order->sendNewOrderEmail();
                $order->setEmailSent(true);
            }
            if ($session->getQuoteId() && $session->getLastSuccessQuoteId()) {
                $session->setBuysafeQuoteId($session->getQuoteId());
                $session->setBuysafeSuccessQuoteId($session->getLastSuccessQuoteId());
                $session->setBuysafeRealOrderId($session->getLastRealOrderId());
                $session->getQuote()->setIsActive(false)->save();
                $session->clear();
            }
            $this->loadLayout();
            $this->renderLayout();
            return;
        } catch (Mage_Core_Exception $e) {
            $this->_getSession()->addError($e->getMessage());
        } catch (Exception $e) {
            Mage::logException($e);
        }
        $this->_redirect('checkout/cart');
    }

    public function resultAction()
    {
        $isSuccess = FALSE;

        try {
            $oSession = $this->_getSession();
            $request = $this->getRequest()->getPost();
            $web = $request['web'];
            $buysafeno = $request['buysafeno'];
            $note1 = $request['note1'];
            $chkValue = $request['ChkValue'];
            $SendType = isset($request["SendType"]) ? $request["SendType"] : 1;
            $MN = isset($request['MN']) ? $request['MN'] : '';
            $ApproveCode = isset($request['ApproveCode']) ? $request['ApproveCode'] : '';
            $Card_NO = isset($request["Card_NO"]) ? $request["Card_NO"] : '';
            $errcode = isset($request['errcode']) ? $request['errcode'] : '';
            $errmsg = isset($request['errmsg']) ? urldecode($request['errmsg']) : '';
            $CargoNo = isset($request['CargoNo']) ? $request['CargoNo'] : '';
            $StoreName = isset($request['StoreName']) ? urldecode($request['StoreName']) : '';
            $StoreID = isset($request['StoreID']) ? $request['StoreID'] : '';
            $StoreType = isset($request['StoreType']) ? $request['StoreType'] : '';
            $StoreMsg = isset($request['StoreMsg']) ? urldecode($request['StoreMsg']) : '';

            if ($note1 == 'buysafe') {
                $payment = 'suntech_' . $note1;
                $oSession->unsBuysafeRealOrderId();
                $oSession->setQuoteId($oSession->getBuysafeQuoteId(true));
                $oSession->setLastSuccessQuoteId($oSession->getBuysafeSuccessQuoteId(true));
                $this->_order = $this->_getOrder($request['Td']);

                // check transaction amount and currency
                if ($this->_getConfigData('use_store_currency')) {
                    $price = intval(round($this->_order->getGrandTotal()));
                    $currency = $this->_order->getOrderCurrencyCode();
                } else {
                    $price = intval(round($this->_order->getGrandTotal()));
                    $currency = $this->_order->getBaseCurrencyCode();
                }

                // check transaction amount
                if ($MN and $price != $request['MN'])
                    Mage::throwException('The grand total doesn\'t match the sum.');

                switch ($chkValue) {
                    case strtoupper(sha1($web . $this->_getConfigData('web_pwd') . $buysafeno . $MN . $errcode . $CargoNo)):
                        $log_exsist = ($this->_order->getState() != Mage_Sales_Model_Order::STATE_PENDING_PAYMENT)?true:false;
                        if ($log_exsist) break;
                        if ($errcode == '00') {
                            $isSuccess = true;
                            $comment = sprintf(Mage::helper($payment)->__('UnionPay Paid'),
                                $buysafeno, $ApproveCode, $Card_NO);
                            $this->_addCustomerComment($comment, $this->_getConfigData('order_paid_status'), true, true, false);

                            if ($this->_order->canInvoice()) { 
                                $invoice = $this->_order->prepareInvoice();
                                $invoice->register()->capture();
                                $invoice->sendEmail(true, $comment);  
                                Mage::getModel('core/resource_transaction')
                                    ->addObject($invoice)
                                    ->addObject($invoice->getOrder())
                                    ->save();
                            }

                            if ($CargoNo) {
                                $comment = sprintf(Mage::helper($payment)->__('CVS Info'),
                                    $CargoNo, $StoreName, $StoreID);
                                $this->_addCustomerComment($comment, $this->_getConfigData('order_paid_status'), false, false, true);
                            }
                        } else {
                            $this->_order->setState(Mage_Sales_Model_Order::STATE_CANCELED, true);
                            $comment = sprintf(Mage::helper('suntech_unionpay')->__('Failed Payments'),
                                $buysafeno, $errmsg);
                            $this->_addCustomerComment($comment);
                        }
                        break;
                    case strtoupper(sha1($web . $this->_getConfigData('web_pwd') . $buysafeno . $StoreType)):
                        switch ($StoreType) {
                            case '1010':
                                $status = Mage_Sales_Model_Order::STATE_COMPLETE;
                                break;
                            default:
                                $status = false;

                        }
                        $this->_addCustomerComment($StoreMsg, $status);
                }
                if ($SendType == 1) {
                    echo '0000';
                    exit;
                }
            }
        } catch (Mage_Core_Exception $e) {
            $this->_getSession()->addError($e->getMessage());
        } catch (Exception $e) {
            Mage::logException($e);
        }


        if ($isSuccess) {
            $this->_redirect('checkout/onepage/success');
        } else {
            $this->_redirect('checkout/onepage/failure');
        }
    }


}