<?php

class SunTech_UnionPay_Model_Payment extends Mage_Payment_Model_Method_Abstract
{
    protected $_code = "suntech_unionpay";
    protected $_formBlockType = 'suntech_unionpay/form_pay';
    protected $_isGateway = false;
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    protected $_canVoid = false;
    protected $_canUseInternal = false;
    protected $_canUseCheckout = true;
    protected $_canUseForMultishipping = false;
    protected $_paymentMethod = 'suntech_unionpay';
    protected $_order;

    public function isAvailable($quote = null)
    {
        if (!parent::isAvailable($quote)) {
            return false;
        }

        if (!$quote) {
            return false;
        }

        if ($quote->getAllVisibleItems() <= 2) {
            return false;
        }

        return true;
    }

    public function validate()
    {
        parent::validate();
        return $this;
    }

    public function getOrderPlaceRedirectUrl()
    {
        return Mage::getUrl('suntech_unionpay/payment/redirect', array('_secure' => false));
    }

}